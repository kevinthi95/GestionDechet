package view;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import gestionDechet.TypeDechet;
import adress.MainApplication;

public class ControleurTypeDechet {

    @FXML
    private ComboBox<TypeDechet> comboBox;  

    private MainApplication mainApp;  

    
    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void initialize() {
        ObservableList<TypeDechet> typeDechetOptions = FXCollections.observableArrayList(TypeDechet.values());
        comboBox.setItems(typeDechetOptions);  
    }
}
