package view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import ConnexionDAO.PoubelleDAO;
import gestionDechet.Poubelle;
import gestionDechet.Couleur;
import adress.MainApplication;

import java.util.List;

public class PoubelleController {

    @FXML private TextField idPoubelleField;
    @FXML private TextField idPoubelleFieldCreer;
    @FXML private TextField idEmplacementField;
    @FXML private TextField couleurField;
    @FXML private TextField idPoubelleFieldSupprimer;
    @FXML private TextField idPoubelleDeplacerField;
    @FXML private TextField nouvelEmplacementField;
    @FXML private TextField idPoubelleFieldInfo;

    private PoubelleDAO poubelleDAO;
    private MainApplication mainApp;

    public PoubelleController() {
        this.poubelleDAO = new PoubelleDAO();
    }

    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    public void handleCreerPoubelle() {
        try {
            int idPoubelle = Integer.parseInt(idPoubelleFieldCreer.getText().trim());
            int idEmplacement = Integer.parseInt(idEmplacementField.getText().trim());
            Couleur couleur = Couleur.valueOf(couleurField.getText().trim().toUpperCase());

            Poubelle nouvellePoubelle = new Poubelle(idPoubelle, idEmplacement, couleur, 0, 1000);
            poubelleDAO.ajouterPoubelle(nouvellePoubelle);
            showAlert("Succès", "Poubelle créée avec succès !");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de la création de la poubelle.");
        }
    }

    @FXML
    public void handleSupprimerPoubelle() {
        try {
            int idPoubelle = Integer.parseInt(idPoubelleFieldSupprimer.getText().trim());
            poubelleDAO.supprimerPoubelle(idPoubelle);
            showAlert("Succès", "Poubelle supprimée !");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de la suppression.");
        }
    }

    @FXML
    public void handleDeplacerPoubelle() {
        try {
            int idPoubelle = Integer.parseInt(idPoubelleDeplacerField.getText().trim());
            int nouvelEmplacement = Integer.parseInt(nouvelEmplacementField.getText().trim());
            poubelleDAO.deplacerPoubelle(idPoubelle, nouvelEmplacement);
            showAlert("Succès", "Poubelle déplacée !");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors du déplacement.");
        }
    }

    @FXML
    public void handleAfficherInformations() {
        try {
            int idPoubelle = Integer.parseInt(idPoubelleFieldInfo.getText().trim());
            Poubelle p = poubelleDAO.getPoubelleById(idPoubelle);

            if (p != null) {
                showAlert("Infos Poubelle", "ID: " + p.getIdPoubelle()
                        + "\nEmplacement: " + p.getIdEmplacement()
                        + "\nCouleur: " + p.getCouleur()
                        + "\nCapacité actuelle: " + p.getCapaciteActuelle()
                        + " / " + p.getCapaciteMax());
            } else {
                showAlert("Erreur", "Poubelle non trouvée !");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de l'affichage.");
        }
    }

    @FXML
    public void handleCollecterPoubellesPleines() {
        try {
            List<Poubelle> pleines = poubelleDAO.getPoubellesPleines();

            if (pleines.isEmpty()) {
                showAlert("Collecte", "Aucune poubelle pleine.");
            } else {
                StringBuilder sb = new StringBuilder();
                for (Poubelle p : pleines) {
                    sb.append("ID: ").append(p.getIdPoubelle())
                      .append(", Emplacement: ").append(p.getIdEmplacement())
                      .append(", Couleur: ").append(p.getCouleur())
                      .append("\n");
                }
                showAlert("Poubelles Pleines", sb.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de la collecte.");
        }
    }

    @FXML
    public void handleViderPoubelle() {
        try {
            int idPoubelle = Integer.parseInt(idPoubelleField.getText().trim());
            Poubelle poubelle = poubelleDAO.getPoubelleById(idPoubelle);

            if (poubelle != null) {
                // Mettre la capacité à zéro dans la base de données
                poubelleDAO.viderPoubelle(idPoubelle);
                showAlert("Succès", "Poubelle vidée !");
            } else {
                showAlert("Erreur", "Poubelle non trouvée !");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors du vidage de la poubelle.");
        }
    }

    @FXML
    public void handleRetour() {
        if (mainApp != null) {
            mainApp.showAccueil();  // Rediriger vers l'accueil
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
