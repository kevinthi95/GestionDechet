package view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import adress.MainApplication;
import ConnexionDAO.DechetsDAO;
import ConnexionDAO.PoubelleDAO;
import ConnexionDAO.CompteDAO;
import gestionDechet.Compte;

public class NotreCompteController {

    @FXML
    private ComboBox<String> comboBox;

    @FXML
    private TextField quantitesField;

    @FXML
    private TextField numPoubelleField;

    @FXML
    private Button btnValiderAjout;

    @FXML
    private Button btnRetour;

    @FXML
    private Label pointsLabel;  // Nouveau Label pour afficher les points

    private MainApplication mainApp;

    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
        updatePointsLabel();  // On met à jour l'affichage des points dès que MainApp est injecté
    }

    @FXML
    private void initialize() {
        comboBox.getItems().addAll("Type 1", "Type 2", "Type 3");
    }

    @FXML
    private void handleValiderAjout() {
        String quantites = quantitesField.getText().trim();
        String selectedDechetType = comboBox.getSelectionModel().getSelectedItem();
        String numPoubelle = numPoubelleField.getText().trim();

        if (quantites.isEmpty() || selectedDechetType == null || numPoubelle.isEmpty()) {
            showAlert("Erreur", "Veuillez remplir tous les champs.");
            return;
        }

        try {
            int idPoubelle = Integer.parseInt(numPoubelle);
            DechetsDAO dechetsDAO = new DechetsDAO();

            if (dechetsDAO.poubelleExiste(idPoubelle)) {
                dechetsDAO.ajouterDechet(Double.parseDouble(quantites), selectedDechetType, "Dépot par poubelle");

                // Mise à jour de la capacité de la poubelle
                PoubelleDAO poubelleDAO = new PoubelleDAO();
                poubelleDAO.ajouterQuantiteDansPoubelle(idPoubelle, Double.parseDouble(quantites));

                // Mise à jour des points de fidélité
                Compte compte = mainApp.getCompte();
                compte.setPointsFidelite(compte.getPointsFidelite() + 10);

                CompteDAO compteDAO = new CompteDAO();
                compteDAO.updatePoints(compte.getId(), compte.getPointsFidelite());

                updatePointsLabel(); // On remet à jour le label après l'ajout

                showAlert("Succès", "Déchet ajouté et 10 points ont été ajoutés à votre compte !");
            } else {
                showAlert("Erreur", "Le numéro de poubelle n'existe pas.");
            }
        } catch (NumberFormatException e) {
            showAlert("Erreur", "Numéro de poubelle invalide !");
        }
    }

    @FXML
    private void handleRetour() {
        if (mainApp != null) {
            mainApp.showAccueil();
        }
    }

    private void updatePointsLabel() {
        if (mainApp != null && mainApp.getCompte() != null) {
            CompteDAO compteDAO = new CompteDAO();
            int points = compteDAO.getPointsByEmail(mainApp.getCompte().getEmail());
            pointsLabel.setText("Points : " + points);
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
