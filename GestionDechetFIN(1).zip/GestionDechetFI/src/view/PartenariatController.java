package view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import ConnexionDAO.ContratDAO;
import gestionDechet.Contrat;
import adress.MainApplication;
import gestionDechet.Compte;

public class PartenariatController {

    @FXML
    private TextField idContratField;
    @FXML
    private TextField idContratRenouvelerField;
    @FXML
    private TextField idCommerceField;
    @FXML
    private TextField descriptionField;
    @FXML
    private DatePicker debutDatePicker;
    @FXML
    private DatePicker finDatePicker;
    @FXML
    private DatePicker newDate;
    @FXML
    private TableView<Contrat> tablePartenariats;
    @FXML
    private TableColumn<Contrat, Integer> columnIdContrat;
    @FXML
    private TableColumn<Contrat, Integer> columnCommerce;
    @FXML
    private TableColumn<Contrat, String> columnDateDebut;
    @FXML
    private TableColumn<Contrat, String> columnDateFin;
    @FXML
    private TableColumn<Contrat, String> columnDescription;
    @FXML
    private TextField idContratSupprField;

    private ObservableList<Contrat> contrats = FXCollections.observableArrayList();

    private MainApplication mainApp;
    private Compte compte;

    @FXML
    private void initialize() {
        // Association des colonnes aux attributs du modèle Contrat
        columnIdContrat.setCellValueFactory(new PropertyValueFactory<>("idContrat"));
        columnCommerce.setCellValueFactory(new PropertyValueFactory<>("idCommerce"));
        columnDateDebut.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDateDebut().toString()));
        columnDateFin.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDateFin().toString()));
        columnDescription.setCellValueFactory(new PropertyValueFactory<>("reglesUtilisation"));

        // Charger les contrats depuis la base de données
        loadContrats();
    }

    private void loadContrats() {
        ContratDAO contratDAO = new ContratDAO();
        List<Contrat> listeContrats = contratDAO.getAllContrats();
        contrats.setAll(listeContrats);
        tablePartenariats.setItems(contrats);
    }

    private void showAlert(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void handleCreerNouveauContrat() {
        try {
            String idContratStr = idContratField.getText().trim();
            String idCommerceStr = idCommerceField.getText().trim();
            String description = descriptionField.getText().trim();
            LocalDate debutDate = debutDatePicker.getValue();
            LocalDate finDate = finDatePicker.getValue();

            if (idContratStr.isEmpty() || idCommerceStr.isEmpty() || description.isEmpty() || debutDate == null || finDate == null) {
                showAlert("Champs manquants", "Veuillez remplir tous les champs !");
                return;
            }

            int idContrat = Integer.parseInt(idContratStr);
            int idCommerce = Integer.parseInt(idCommerceStr);

            Contrat nouveauContrat = new Contrat(idContrat, idCommerce, debutDate, finDate, description);

            ContratDAO contratDAO = new ContratDAO();
            contratDAO.ajouterContrat(nouveauContrat);

            showAlert("Succès", "Contrat créé et sauvegardé dans la base de données !");
            loadContrats(); // Recharger après ajout

            idContratField.clear();
            idCommerceField.clear();
            descriptionField.clear();
            debutDatePicker.setValue(null);
            finDatePicker.setValue(null);
        } catch (NumberFormatException e) {
            showAlert("Erreur", "L'ID doit être un nombre entier !");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur interne", "Une erreur est survenue lors de la création du contrat.");
        }
    }

    @FXML
    public void handleSupprimerContrat() {
        String idContratStr = idContratSupprField.getText().trim();
        if (idContratStr.isEmpty()) {
            showAlert("Champ vide", "L'ID du contrat ne peut pas être vide.");
            return;
        }

        try {
            int idContrat = Integer.parseInt(idContratStr);

            ContratDAO contratDAO = new ContratDAO();
            contratDAO.supprimerContrat(idContrat);

            showAlert("Succès", "Contrat supprimé avec succès !");
            loadContrats(); // Recharger après suppression

            idContratSupprField.clear();
        } catch (NumberFormatException e) {
            showAlert("Erreur", "L'ID du contrat doit être un nombre entier.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur interne", "Une erreur est survenue lors de la suppression du contrat.");
        }
    }

    @FXML
    public void handleRenouvelerContrat() {
        try {
            String idContratStr = idContratRenouvelerField.getText().trim();
            if (idContratStr.isEmpty()) {
                showAlert("Champ vide", "L'ID du contrat ne peut pas être vide.");
                return;
            }

            int idContrat = Integer.parseInt(idContratStr);
            LocalDate nouvelleDateFin = newDate.getValue();
            if (nouvelleDateFin == null) {
                showAlert("Date manquante", "Veuillez sélectionner une nouvelle date de fin.");
                return;
            }

            ContratDAO contratDAO = new ContratDAO();
            boolean contratRenouvele = contratDAO.renouvelerContrat(idContrat, nouvelleDateFin);

            if (contratRenouvele) {
                showAlert("Succès", "Contrat renouvelé avec succès !");
            } else {
                showAlert("Erreur", "Aucun contrat trouvé avec l'ID " + idContrat);
            }

            loadContrats(); // Recharger après mise à jour
            idContratRenouvelerField.clear();
            newDate.setValue(null);
        } catch (NumberFormatException e) {
            showAlert("Erreur", "L'ID du contrat doit être un nombre entier valide.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur interne", "Une erreur est survenue lors du renouvellement du contrat.");
        }
    }

    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    public void setCompte(Compte compte) {
        this.compte = compte;
    }

    @FXML
    public void handleRetour() {
        if (mainApp != null) {
            mainApp.showAccueil();
        }
    }
}
