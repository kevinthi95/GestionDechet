package view;

import adress.MainApplication;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class InscriptionOuConnectionController {

    @FXML
    private Button btnInscription;  // Bouton Inscription

    @FXML
    private Button btnConnexion;    // Bouton Connexion

    private MainApplication mainApp;

    // Injection du MainApplication
    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void initialize() {
        // Configurer les actions des boutons
        btnInscription.setOnAction(event -> openInscriptionWindow());
        btnConnexion.setOnAction(event -> openConnectionWindow());
    }

    // Méthode pour ouvrir la fenêtre d'inscription
    private void openInscriptionWindow() {
        if (mainApp != null) {
            mainApp.openInscriptionWindow();  // Ouvre la fenêtre d'inscription
        }
    }

    // Méthode pour ouvrir la fenêtre de connexion
    private void openConnectionWindow() {
        if (mainApp != null) {
            mainApp.openConnectionWindow();  // Ouvre la fenêtre de connexion
        }
    }
}
