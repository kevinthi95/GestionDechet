package view;

import java.util.Random;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import adress.MainApplication;
import gestionDechet.Compte;

public class StatistiqueController {

    @FXML
    private Label quantiteMaxLabel;
    @FXML
    private Label depotMoyenLabel;
    @FXML
    private Label quantiteTotaleDepotLabel;
    @FXML
    private Label nombresDepotLabel;

    @FXML
    private Button btnRetour;

    private Stage stage;
    private MainApplication mainApp;  // Référence à MainApplication

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    // Injecter MainApplication dans StatistiqueController
    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;  // Assurez-vous que l'instance de MainApplication est injectée
    }

    // Méthode d'initialisation appelée lors du démarrage de la vue
    @FXML
    public void initialize() {
    	System.out.println("StatistiqueController initialized");
        // Simuler des données avec des valeurs aléatoires
        Random rand = new Random();

        double quantiteMax = 50 + rand.nextDouble() * 150; // 50 à 200 kg
        double depotMoyen = 10 + rand.nextDouble() * 30;   // 10 à 40 kg
        double totalDepot = quantiteMax * 5;
        int nombreDepot = rand.nextInt(50) + 1;

        // Mise à jour des labels avec les valeurs simulées
        quantiteMaxLabel.setText(String.format("%.2f", quantiteMax));
        depotMoyenLabel.setText(String.format("%.2f", depotMoyen));
        quantiteTotaleDepotLabel.setText(String.format("%.2f", totalDepot));
        nombresDepotLabel.setText(String.valueOf(nombreDepot));

        // Gestion de l'action du bouton retour
        btnRetour.setOnAction(event -> {
            if (mainApp != null && mainApp.getCompte() != null) {
                mainApp.showAccueil();  // Retour à la page d'Accueil avec l'objet 'compte'
            }
        });
    }

    // Méthode pour charger les statistiques avec des valeurs données
    public void chargerStatistiques(double max, double moyenne, double total, int nbDepots) {
        quantiteMaxLabel.setText(String.format("%.2f", max));
        depotMoyenLabel.setText(String.format("%.2f", moyenne));
        quantiteTotaleDepotLabel.setText(String.format("%.2f", total));
        nombresDepotLabel.setText(String.valueOf(nbDepots));
    }
}
