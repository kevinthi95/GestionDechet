package gestionDechetTest;

public class MainTest {
	public static void main(String[] args) {
		TestPoubelle.main(null);
		TestContrat.main(null);
		TestCommerce.main(null);
		TestCategorieProduit.main(null);
		TestProduit.main(null);
		TestDepot.main(null);
		TestCompte.main(null);
		TestCentreDeTri.main(null);
	}
}
