package ConnexionBDD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // URL de la base de données
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_dechets"; 
    private static final String USER = "root"; 
    private static final String PASSWORD = "rootroot"; 

    // Méthode pour établir la connexion à la base de données
    public static Connection connect() throws SQLException {
        try {
            // Connexion à la base de données MySQL
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erreur de connexion à la base de données");
        }
    }
}
