package adress;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import view.AcceuilController;
import view.CommerceController;
import view.ConnectionController;
import view.InscriptionController;
import view.InscriptionOuConnectionController;
import view.NotreCompteController;
import view.PartenariatController;
import view.PoubelleController;
import view.StatistiqueController;
import gestionDechet.Compte;

import java.io.IOException;
import java.net.URL;

import ConnexionDAO.CompteDAO;

public class MainApplication extends Application {

    private Stage primaryStage;
    private Compte compte;  // Déclaration de la variable compte

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Projet GMF 4, groupe 1");
        showInscriptionOuConnection();
    }

    public Compte getCompte() {
        return compte; // Renvoie l'objet compte actuel
    }

    public void setCompte(Compte compte) {
        this.compte = compte; // Assigne un compte à MainApplication

        // Récupérer les points depuis la base de données
        CompteDAO compteDAO = new CompteDAO();
        int points = compteDAO.getPointsByEmail(compte.getEmail());  // Récupère les points de l'utilisateur
        compte.setPointsFidelite(points); // Met à jour les points de l'utilisateur
    }


    public void showInscriptionOuConnection() {
        try {
            // Si compte est null, l'initialiser (par exemple, avec un utilisateur par défaut)
            if (compte == null) {
                compte = new Compte(); // Initialiser avec un compte par défaut ou via une méthode de connexion
            }

            URL fxmlUrl = getClass().getResource("/view/InscriptionOuConnection.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            BorderPane rootLayout = loader.load();

            // Injection de MainApplication dans le contrôleur
            InscriptionOuConnectionController controller = loader.getController();
            controller.setMainApp(this);

            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showAccueil() {
        try {
            if (compte == null) {
                showInscriptionOuConnection(); // Si aucun compte n'est connecté, on revient à la page de connexion
                return;
            }

            URL fxmlUrl = getClass().getResource("/view/Accueil.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Accueil.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane accueilLayout = loader.load();

            AcceuilController controller = loader.getController();
            controller.setMainApp(this); // Passer l'instance de MainApplication
            controller.setCompte(compte); // Passer l'objet compte au contrôleur

            Scene scene = new Scene(accueilLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public void showPartenariat() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Partenariat.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Partenariat.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane partenariatLayout = loader.load();

            // Injection de MainApplication et de Compte dans le contrôleur
            PartenariatController controller = loader.getController();
            controller.setMainApp(this);  // Passer l'instance de MainApplication
            controller.setCompte(compte);  // Passer l'objet Compte au contrôleur

            Scene scene = new Scene(partenariatLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void showCommerce() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Commerce.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Commerce.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane commerceLayout = loader.load();

            // Injecter l'application (mainApp) et l'objet compte dans le contrôleur
            CommerceController controller = loader.getController();
            controller.setMainApp(this);  // Passer l'instance de MainApplication
            controller.setCompte(compte);  // Passer l'objet compte au contrôleur

            Scene scene = new Scene(commerceLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showPoubelle() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Poubelles.fxml"); // Assure-toi que ce chemin est correct
            if (fxmlUrl == null) {
                System.err.println("Fichier Poubelle.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane poubelleLayout = loader.load();

            // Injection du contrôleur avec l'instance de MainApplication
            PoubelleController controller = loader.getController();
            controller.setMainApp(this); // Assurez-vous que MainApplication est bien passé ici

            Scene scene = new Scene(poubelleLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void showStatistique() {
        try {
            // Load the FXML for Statistique page
            URL fxmlUrl = getClass().getResource("/view/Statistiques.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Statistiques.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane statistiqueLayout = loader.load();

            // Get the controller and inject the MainApplication instance
            StatistiqueController controller = loader.getController();
            controller.setMainApp(this);  // Pass the MainApplication to the controller

            // Set up the scene and stage
            Scene scene = new Scene(statistiqueLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }





    public void showNotreCompte(Compte compte) {
        try {
            // Charger le fichier FXML pour la page "NotreCompte"
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApplication.class.getResource("/view/NotreCompte.fxml"));
            AnchorPane notreComptePage = loader.load();

            // Passer l'objet compte au contrôleur
            NotreCompteController controller = loader.getController();
            controller.setMainApp(this); // Passer l'objet compte

            // Afficher la scène
            Scene scene = new Scene(notreComptePage);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    
    public void openConnectionWindow() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Connection.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML Connection");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane connectionLayout = loader.load();

            ConnectionController controller = loader.getController();
            controller.setMainApp(this); // Injection du Main dans le contrôleur

            Scene scene = new Scene(connectionLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void openInscriptionWindow() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Inscription.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML Inscription");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane inscriptionLayout = loader.load();

            // Injection du contrôleur dans le fichier FXML
            InscriptionController controller = loader.getController();
            controller.setMainApp(this); // Passer l'instance de MainApplication au contrôleur

            Scene scene = new Scene(inscriptionLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        launch(args);
    }
 

} 