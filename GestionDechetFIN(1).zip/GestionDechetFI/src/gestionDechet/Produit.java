package gestionDechet;

import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Produit {

    private final IntegerProperty idProduit;
    private final StringProperty nom;
    private final FloatProperty prix;

    // Constructeur
    public Produit(int id, String nom, float prix) {
        this.idProduit = new SimpleIntegerProperty(id);
        this.nom = new SimpleStringProperty(nom);
        this.prix = new SimpleFloatProperty(prix);
    }

    // Getters et setters
    public int getIdProduit() {
        return idProduit.get();
    }

    public void setIdProduit(int idProduit) {
        this.idProduit.set(idProduit);
    }

    public IntegerProperty idProduitProperty() {
        return idProduit;
    }

    public String getNom() {
        return nom.get();
    }

    public void setNom(String nom) {
        this.nom.set(nom);
    }

    public StringProperty nomProduitProperty() {
        return nom;
    }

    public float getPrix() {
        return prix.get();
    }

    public void setPrix(float prix) {
        this.prix.set(prix);
    }

    public FloatProperty prixProduitProperty() {
        return prix;
    }

    @Override
    public String toString() {
        return "Produit{" +
                "idProduit=" + idProduit.get() +
                ", nom='" + nom.get() + '\'' +
                ", prix=" + prix.get() +
                '}';
    }
}     