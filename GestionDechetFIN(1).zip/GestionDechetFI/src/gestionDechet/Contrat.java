package gestionDechet;

import java.time.LocalDate;

public class Contrat {

    private int idContrat;
    private int idCommerce;
    private LocalDate dateDebut;
    private LocalDate dateFin;
    private String reglesUtilisation;

    public Contrat(int idContrat, int idCommerce, LocalDate dateDebut, LocalDate dateFin, String reglesUtilisation) {
        this.idContrat = idContrat;
        this.idCommerce = idCommerce;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.reglesUtilisation = reglesUtilisation;
    }

    public int getIdContrat() {
        return idContrat;
    }

    public void setIdContrat(int idContrat) {
        this.idContrat = idContrat;
    }

    public int getIdCommerce() {
        return idCommerce;
    }

    public void setIdCommerce(int idCommerce) {
        this.idCommerce = idCommerce;
    }

    public LocalDate getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(LocalDate dateDebut) {
        this.dateDebut = dateDebut;
    }

    public LocalDate getDateFin() {
        return dateFin;
    }

    public void setDateFin(LocalDate dateFin) {
        this.dateFin = dateFin;
    }

    public String getReglesUtilisation() {
        return reglesUtilisation;
    }

    public void setReglesUtilisation(String reglesUtilisation) {
        this.reglesUtilisation = reglesUtilisation;
    }

    public boolean renouvelerContrat(LocalDate nouvelleDateFin) {
        System.out.println("📝 Renouvellement demandé pour contrat ID " + idContrat);
        System.out.println("Ancienne date de fin : " + this.dateFin);
        System.out.println("Nouvelle date proposée : " + nouvelleDateFin);

        if (!nouvelleDateFin.isBefore(this.dateFin)) {
            this.dateFin = nouvelleDateFin;
            System.out.println("✅ Date mise à jour !");
            return true;
        } else {
            System.out.println("❌ La nouvelle date doit être postérieure ou égale à la date actuelle.");
            return false;
        }
    }
}
