package gestionDechet;

public class Poubelle {

    private int idPoubelle;
    private final float capaciteMax = 1000.0f;  // La capacité maximale est constante
    private float capaciteActuelle;  // La capacité actuelle, modifiable
    private int idEmplacement;
    private Couleur couleur;

    // Constructeur modifié
    public Poubelle(int idPoubelle, int idEmplacement, Couleur couleur, float capaciteActuelle, int capaciteMax) {
        this.idPoubelle = idPoubelle;
        this.idEmplacement = idEmplacement;
        this.couleur = couleur;
        this.capaciteActuelle = capaciteActuelle;  // Initialisation de la capacité actuelle
    }

    // Getters et setters
    public int getIdPoubelle() {
        return idPoubelle;
    }

    public int getIdEmplacement() {
        return idEmplacement;
    }

    public Couleur getCouleur() {
        return couleur;
    }

    public float getCapaciteActuelle() {
        return capaciteActuelle;
    }

    public void setCapaciteActuelle(float capaciteActuelle) {
        this.capaciteActuelle = capaciteActuelle;
    }

    public float getCapaciteMax() {
        return capaciteMax;  // La capacité max est constante et ne change pas
    }

    public boolean pleine() {
        return capaciteActuelle >= capaciteMax;
    }

    // Afficher les informations de la poubelle
    public void afficherInfos() {
        System.out.println("ID Poubelle : " + idPoubelle +
                           " | Emplacement : " + idEmplacement +
                           " | Couleur : " + couleur +
                           " | Capacité actuelle : " + capaciteActuelle);
    }

    // Afficher la quantité de déchets dans la poubelle
    public void quantiteDechets() {
        System.out.println("La poubelle contient " + capaciteActuelle + " kg sur " + capaciteMax + " kg. Il reste donc " + (capaciteMax - capaciteActuelle) + " kg de libre.");
    }

    // Vérifier si la poubelle est pleine et afficher un message
    public void estPleine() {
        if (this.capaciteActuelle == this.capaciteMax) {
            System.out.println("La poubelle est pleine");
        } else {
            System.out.println("La poubelle n'est pas encore pleine");
        }
    }
}
