package gestionDechet;

/**
 * 
 */
public enum TypeDechet {
    CARTON,
    VERRE,
    CONSERVE,
    PAPIER,
    CANETTE,
    EMBALLAGE,
    PLASTIQUE,
    AUTRE    
}