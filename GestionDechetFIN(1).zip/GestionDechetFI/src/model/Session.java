package model;

public class Session {
    private static String idUtilisateur;

    public static void connecter(String id) {
        idUtilisateur = id;
    }

    public static String getIdUtilisateur() {
        return idUtilisateur;
    }

    public static boolean estConnecte() {
        return idUtilisateur != null;
    }

    public static void deconnecter() {
        idUtilisateur = null;
    }
}
