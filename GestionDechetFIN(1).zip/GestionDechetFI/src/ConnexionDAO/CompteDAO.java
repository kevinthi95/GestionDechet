package ConnexionDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import ConnexionBDD.DatabaseConnection;

public class CompteDAO {

    private Connection connection;

    public CompteDAO() {
        try {
            connection = DatabaseConnection.connect();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    } // Mettre à jour les points d'un utilisateur
  

    // Récupérer les points d'un utilisateur par son email
    public int getPointsByEmail(String email) {
        String query = "SELECT points FROM comptes WHERE email = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, email);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getInt("points");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; // Retourne 0 si l'utilisateur n'existe pas
    }

    // Mettre à jour les points de l'utilisateur
    public void updatePointsByEmail(String email, int newPoints) {
        String query = "UPDATE comptes SET points = ? WHERE email = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, newPoints);
            statement.setString(2, email);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    // Mettre à jour les points d'un utilisateur
    public void updatePoints(int userId, int points) {
        String query = "UPDATE comptes SET points = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, points);
            statement.setInt(2, userId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
