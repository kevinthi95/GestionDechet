package ConnexionDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DechetsDAO {

    private final String url = "jdbc:mysql://localhost:3306/gestion_dechets";
    private final String user = "root";
    private final String password = "rootroot";

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    public boolean poubelleExiste(int idPoubelle) {
        String query = "SELECT id_poubelle FROM poubelle WHERE id_poubelle = ?";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, idPoubelle);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void ajouterDechet(double quantite, String typeDechet, String typeDepot) {
        String query = "INSERT INTO dechets (quantite, type_dechet, type_depot) VALUES (?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDouble(1, quantite);
            stmt.setString(2, typeDechet);
            stmt.setString(3, typeDepot);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
