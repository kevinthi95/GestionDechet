package ConnexionDAO;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import ConnexionBDD.DatabaseConnection;
import gestionDechet.Contrat;

public class ContratDAO {
    private Connection connection;

    // Constructeur qui initialise la connexion à la base de données
    public ContratDAO() {
        try {
            this.connection = DatabaseConnection.connect(); // Utiliser connect() au lieu de getConnection()
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 // Mettre à jour les points d'un utilisateur
    public void updatePoints(int userId, int points) {
        String query = "UPDATE comptes SET points = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, points);
            statement.setInt(2, userId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Méthode pour ajouter un contrat
    public void ajouterContrat(Contrat contrat) {
        String query = "INSERT INTO contrats (id_contrat, id_commerce, description, date_debut, date_fin) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, contrat.getIdContrat());  // Utiliser l'ID spécifié par l'utilisateur
            statement.setInt(2, contrat.getIdCommerce());
            statement.setString(3, contrat.getReglesUtilisation());
            statement.setDate(4, Date.valueOf(contrat.getDateDebut()));
            statement.setDate(5, Date.valueOf(contrat.getDateFin()));

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Contrat ajouté avec succès !");
            } else {
                System.out.println("Aucune ligne insérée.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour supprimer un contrat
    public void supprimerContrat(int idContrat) {
        String query = "DELETE FROM contrats WHERE id_contrat = ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, idContrat);
            statement.executeUpdate();
            System.out.println("Contrat supprimé avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour récupérer tous les contrats
    public List<Contrat> getAllContrats() {
        List<Contrat> contrats = new ArrayList<>();
        String query = "SELECT * FROM contrats";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                int idContrat = resultSet.getInt("id_contrat");
                int idCommerce = resultSet.getInt("id_commerce");
                String description = resultSet.getString("description");
                Date dateDebut = resultSet.getDate("date_debut");
                Date dateFin = resultSet.getDate("date_fin");

                Contrat contrat = new Contrat(idContrat, idCommerce, dateDebut.toLocalDate(), dateFin.toLocalDate(), description);
                contrats.add(contrat);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return contrats;
    }

    // Méthode pour renouveler un contrat
    public boolean renouvelerContrat(int idContrat, LocalDate nouvelleDateFin) {
        String query = "UPDATE contrats SET date_fin = ? WHERE id_contrat = ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDate(1, Date.valueOf(nouvelleDateFin));
            statement.setInt(2, idContrat);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Contrat renouvelé avec succès !");
                return true;
            } else {
                System.out.println("Aucun contrat trouvé avec l'ID " + idContrat);
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
