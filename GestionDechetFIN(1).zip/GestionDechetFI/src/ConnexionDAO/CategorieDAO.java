package ConnexionDAO;

import java.sql.*;
import ConnexionBDD.DatabaseConnection;

public class CategorieDAO {

    public ResultSet getCategoriesByCommerce(int idCommerce) {
        String query = "SELECT * FROM categorie WHERE id_commerce = ?";

        try {
            Connection conn = DatabaseConnection.connect();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idCommerce);
            return stmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getIdCategorieByName(String nomCategorie, int idCommerce) {
        int id = -1;
        String query = "SELECT id_categorie FROM categorie WHERE nom_categorie = ? AND id_commerce = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nomCategorie);
            stmt.setInt(2, idCommerce);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                id = rs.getInt("id_categorie");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }
}
