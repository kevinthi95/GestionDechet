package utils;

import gestionDechet.Poubelle;
import gestionDechet.Couleur;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class PoubelleXMLManager {

    private static final String FILE_PATH = "data/poubelles.xml";

    // Initialiser le fichier XML
    public static void initXMLFile() {
        System.out.println("✅ Appel de initXMLFile()");

        try {
            File file = new File(FILE_PATH);
            File parentDir = file.getParentFile();

            System.out.println("📁 Vérification du dossier parent : " + parentDir.getAbsolutePath());

            if (!parentDir.exists()) {
                boolean created = parentDir.mkdirs();
                System.out.println("📂 Dossier 'data/' créé : " + created);
            } else {
                System.out.println("📂 Dossier 'data/' déjà existant");
            }

            if (!file.exists()) {
                System.out.println("📄 Le fichier XML n'existe pas, création en cours...");

                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                Document doc = dBuilder.newDocument();

                Element rootElement = doc.createElement("poubelles");
                doc.appendChild(rootElement);

                saveDocument(doc);

                System.out.println("✅ Fichier XML créé : " + FILE_PATH);
            } else {
                System.out.println("📁 Le fichier XML existe déjà : " + FILE_PATH);
            }
        } catch (Exception e) {
            System.out.println("🔥 Erreur lors de l'initialisation du fichier XML : " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Charger les poubelles
    public static List<Poubelle> loadPoubelles() {
        List<Poubelle> poubelles = new ArrayList<>();
        try {
            File file = new File(FILE_PATH);
            if (!file.exists()) {
                System.out.println("❌ Aucun fichier trouvé à charger.");
                return poubelles;
            }

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(file);

            NodeList nodeList = doc.getElementsByTagName("poubelle");

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    int idPoubelle = Integer.parseInt(element.getElementsByTagName("idPoubelle").item(0).getTextContent());
                    int idEmplacement = Integer.parseInt(element.getElementsByTagName("idEmplacement").item(0).getTextContent());
                    String couleurStr = element.getElementsByTagName("couleur").item(0).getTextContent();
                    Couleur couleur = Couleur.valueOf(couleurStr.toUpperCase());
                    float capaciteActuelle = Float.parseFloat(element.getElementsByTagName("capaciteActuelle").item(0).getTextContent());

                    Poubelle poubelle = new Poubelle(idPoubelle, idEmplacement, couleur);
                    poubelle.setCapaciteActuelle(capaciteActuelle);
                    poubelles.add(poubelle);
                }
            }

            System.out.println("📥 Chargement des poubelles terminé. Total : " + poubelles.size());

        } catch (Exception e) {
            System.out.println("🔥 Erreur lors du chargement des poubelles : " + e.getMessage());
            e.printStackTrace();
        }

        return poubelles;
    }

    // Sauvegarder les poubelles
    public static void saveAllPoubelles(List<Poubelle> poubelles) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();

            Element rootElement = doc.createElement("poubelles");
            doc.appendChild(rootElement);

            for (Poubelle poubelle : poubelles) {
                Element poubelleEl = doc.createElement("poubelle");

                createChild(doc, poubelleEl, "idPoubelle", String.valueOf(poubelle.getIdPoubelle()));
                createChild(doc, poubelleEl, "idEmplacement", String.valueOf(poubelle.getIdEmplacement()));
                createChild(doc, poubelleEl, "couleur", poubelle.getCouleur().toString());
                createChild(doc, poubelleEl, "capaciteActuelle", String.valueOf(poubelle.getCapaciteActuelle()));
                createChild(doc, poubelleEl, "capaciteMax", String.valueOf(poubelle.getCapaciteMax()));

                rootElement.appendChild(poubelleEl);
            }

            saveDocument(doc);
            System.out.println("💾 Poubelles sauvegardées avec succès.");

        } catch (Exception e) {
            System.out.println("🔥 Erreur lors de la sauvegarde XML : " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void createChild(Document doc, Element parent, String name, String value) {
        Element elem = doc.createElement(name);
        elem.appendChild(doc.createTextNode(value));
        parent.appendChild(elem);
    }

    private static void saveDocument(Document doc) throws TransformerException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new File(FILE_PATH));

        transformer.transform(source, result);
    }
}
